package com.demo.collection;
import java.util.*;

//Demo on ArrayList
public class DemoArrayList {
	public static void main(String[] args) {
		
		List<String> names=new ArrayList<String>();
		names.add("kar");
		names.add("zee");
		names.add("foo");
		names.add("jar");
	
		Collections.sort(names);
		int loc=Collections.binarySearch(names, "jja");
		
		System.out.println(names);
		//Iterator DP: iteration is the way of moving in a collection
		
		/*Iterator<String> it=names.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		*/
		// java.lang.IllegalStateException
		
		/*
		 * [foo, jar, kar, zee]
		kar
		zee

		 */
		Iterator<String> it=names.iterator();
		it.next();
		it.remove();
		it.next();
		it.remove();
		
		while(it.hasNext()){
			String val=it.next();
			System.out.println(val);
		}
		
		
		
		/*for(String name: names)
			System.out.println(name);*/
		
		
		/*System.out.println("jja");
		System.out.println(loc);*/
	}

}
