package com.demo.collection;
import java.util.*;

//Demo on ArrayList
public class CDemoLinkList {
	public static void main(String[] args) {
		//[foo, jar, kar, zee]
		List<String> names=new LinkedList<String>();
		names.add("kar");
		names.add("zee");
		names.add("foo");
		names.add("jar");
	
		Collections.sort(names);
		int loc=Collections.binarySearch(names, "jja");
		
		System.out.println(names);
		
		Iterator it=names.iterator();
		
		while(it.hasNext()){
			String val=(String) it.next();
			System.out.println(val);
		}
		
		
		
		/*for(String name: names)
			System.out.println(name);*/
		
		
		/*System.out.println("jja");
		System.out.println(loc);*/
	}

}
