package com.demo.collection;
import java.util.*;
public class DemoHashMap {
	public static void main(String[] args) {
		Map<String, String>map=new HashMap<String, String>();
		map.put("a", "fooA");
		map.put("b", "fooB");
		map.put("c", "fooC");
		map.put("d", "fooD");
		
		
	}

}
