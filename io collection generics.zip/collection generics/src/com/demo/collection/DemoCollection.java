package com.demo.collection;
import java.util.*;
public class DemoCollection {
	
	public static void main(String[] args) {
		
		List<String> list=new ArrayList<String>();
		list.add("foo");
		list.add("bar");
		list.add("jar");
		list.add("kar");
		
		list.subList(1, 3).clear();
		System.out.println(list);
		
	}

	

}
