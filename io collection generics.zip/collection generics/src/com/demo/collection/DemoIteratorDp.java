package com.demo.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
//how to have uniform interface is managed by itertor design pattern
//Iterator vs Iterable
class Item {

	String name;
	float price;

	public Item(String name, float price) {
		this.name = name;
		this.price = price;
	}

	public String toString() {
		return name + ": $" + price;
	}
}

class Menu implements Iterable<Item>{

	List<Item> menuItems;

	public Menu() {
		menuItems = new LinkedList<Item>();
	}

	public void addItem(Item item) {
		menuItems.add(item);
	}

	@Override
	public Iterator<Item> iterator() {
		return new MenuIterator();
	}
	
	class MenuIterator implements Iterator<Item>{
		int currentIndex = 0;

		@Override
		public boolean hasNext() {
			if (currentIndex >= menuItems.size()) {
				return false;
			} else {
				return true;
			}
		}

		@Override
		public Item next() {
			return menuItems.get(currentIndex++);
		}

		@Override
		public void remove() {
			menuItems.remove(--currentIndex);
		}
		
	}
}
public class DemoIteratorDp {
	
	public static void main(String[] args) {
		Menu menu=new Menu();
		menu.addItem(new Item("mouse", 333.66f));
		menu.addItem(new Item("TV", 888033.66f));
		menu.addItem(new Item("laptop", 9333.66f));
		
		Iterator<Item> iterator = menu.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		
	}

}
