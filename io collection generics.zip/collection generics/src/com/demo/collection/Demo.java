package com.demo.collection;

public class Demo {

}
