package com.demo.collection;
import java.util.*;
import java.io.*;

public class DemoSet {

	public static void main(String[] args) {
		
		String line=null;
		// design as per interface
		
		Set<String> set=new TreeSet<String>();
		
		try {
			BufferedReader  br=
					new BufferedReader(new FileReader("foo.txt"));
			
			while((line=br.readLine())!=null){
				String []tokens=line.split(" ");
				for(String token: tokens){
					set.add(token.toLowerCase());
				}
					
			}
			// StringTokenizer vs split method (split method)
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// print it 
		for(String s: set)
			System.out.println(s);
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		 * 1. read the file till end 
		 * 2. make token of each line
		 * 3. put token in set
		 * 4. print that
		 */
	}
}
