package com.demo.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Box implements Serializable {

	private static final long serialVersionUID = 
			-4613675255654650263L;
	
	
	private int l, b;
	private int h;
	
	

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}


	public Box(int l, int b) {
		this.l = l;
		this.b = b;
	}

	@Override
	public String toString() {
		return "Box [l=" + l + ", b=" + b + "]";
	}

}

public class DemoSeri {

	public static void main(String[] args)  {
		//Ser
		
		Box box=new Box(12, 12);
		
		//Java 7: ARM
		
		/*
		try {
			ObjectOutputStream oos=new ObjectOutputStream
					(new FileOutputStream(new File("foo.txt")));
			oos.writeObject(box);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
		
		// De-ser
		box=null;

		
		try {
			ObjectInputStream ois=new ObjectInputStream
					(new FileInputStream(new File("foo.txt")));
			box=(Box) ois.readObject();
			System.out.println(box);
			
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}














