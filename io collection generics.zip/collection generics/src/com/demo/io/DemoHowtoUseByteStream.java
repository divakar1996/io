package com.demo.io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DemoHowtoUseByteStream {

	public static void main(String[] args) {
		try (DataOutputStream dos = new DataOutputStream(new FileOutputStream("temp.txt"))) {
			for (int i = 0; i < 10; i++) {
				dos.writeByte(i);
				dos.writeShort(i);
				dos.writeInt(i);
			}
		} catch (IOException e) {

		}

		try (DataInputStream dis = new DataInputStream(new FileInputStream("temp.txt"))) {
			for (int i = 0; i < 10; i++) {
				System.out.printf("%d %d %d", dis.readByte(), dis.readShort(),dis.readInt());
			}
		} catch (IOException e) {

		}
	}
}
