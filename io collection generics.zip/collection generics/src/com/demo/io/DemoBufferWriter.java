package com.demo.io;
import java.io.*;

public class DemoBufferWriter {
	
	public static void main(String[] args) throws IOException {
		File file=new File("foo.txt");//5
		FileWriter fw=new FileWriter(file);//4
		BufferedWriter bwriter=new BufferedWriter(fw);
		bwriter.write("java is good programming in 2018");
		bwriter.flush();
		bwriter.close();
		
		
	}

}
