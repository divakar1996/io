package com.demo.io;

import java.io.File;
import java.io.FileFilter;

public class PrintAllHiddenFileInADir {
	
	public static void main(String[] args) {
		File file=new File("/opt/eclipse");
		if(file.isDirectory()){
			File[]files=file.listFiles(new FileFilter() {
				
				@Override
				public boolean accept(File f) {
				
					return f.canExecute();
				}
			});
			for(File f: files)
				System.out.println(f.getName());
		}
		
	}

}
