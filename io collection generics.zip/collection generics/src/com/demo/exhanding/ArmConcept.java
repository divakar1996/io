package com.demo.exhanding;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//Automatic res mgt ==> java 1.7

public class ArmConcept {

	public static void main(String[] args) {
		//java 7-> 8--->9
		//BufferedReader br=null;
		
		try (BufferedReader br=new BufferedReader(new FileReader(new File("foo.txt")))){
			
		
		} catch (IOException e) {
		
			e.printStackTrace();
		}finally{
			
		}
	}
}
