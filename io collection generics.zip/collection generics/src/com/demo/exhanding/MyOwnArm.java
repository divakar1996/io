package com.demo.exhanding;


class Door implements AutoCloseable{
	public Door(){
		System.out.println("its a ctr");
	}
	@Override
	public void close() throws Exception {
		System.out.println("i can write resource cleaning code...");
	}
	
	public void doWork(){
		System.out.println("start study...");
	}
	
}
public class MyOwnArm {

	public static void main(String[] args) {
		try(Door d=new Door()){
			d.doWork();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


