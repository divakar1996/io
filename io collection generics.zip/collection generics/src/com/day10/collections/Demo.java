package com.day10.collections;

import java.util.*;
import java.io.*;

//Comparable and Comparator

class BookSorterAsPerTitle implements Comparator<Book> {

	@Override
	public int compare(Book o1, Book o2) {
		return o2.getName().compareTo(o1.getName());
	}
}

class BookSorterAsPerPrice implements Comparator<Book> {

	@Override
	public int compare(Book o1, Book o2) {
		return Double.compare(o1.getPrice(), o2.getPrice());
	}
}

class Book implements Comparable<Book> {
	private int id;
	private String name;
	private double price;
	private int noOfPages;
	private String author;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getNoOfPages() {
		return noOfPages;
	}

	public void setNoOfPages(int noOfPages) {
		this.noOfPages = noOfPages;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Book(int id, String name, double price, int noOfPages, String author) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.noOfPages = noOfPages;
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", price=" + price
				+ ", noOfPages=" + noOfPages + ", author=" + author + "]";
	}

	@Override
	public int compareTo(Book o) {
		System.out.println("&&&&&&&&&");
		return Integer.compare(this.getId(), o.getId());
	}

}

public class Demo {

	public static void main(String[] args) throws IOException {

		// Generics?
		List<Book> books = new ArrayList<Book>();

		BufferedReader br = new BufferedReader(new FileReader(new File(
				"data.txt")));

		String line = null;
		Book tempBook = null;
		while ((line = br.readLine()) != null) {
			String tokens[] = line.split(",");
			tempBook = new Book(Integer.parseInt(tokens[0]), tokens[1],
					Double.parseDouble(tokens[2]), 
					Integer.parseInt(tokens[3]),
					tokens[4]);
			books.add(tempBook);
		}

		for(Book book: books){
			System.out.println(book);
		}
		
		
		
		/*
		 * books.add(new Book(12991, "let us c", 340, 400, "YK")); books.add(new
		 * Book(1, "let us java", 500, 400, "AK")); books.add(new Book(91,
		 * "thinking in java", 500, 800, "Bruce")); books.add(new Book(71,
		 * "gang of 4 design patter", 640, 800, "YK"));
		 * 
		 * 
		 * for (Book book : books) System.out.println(book); // Enu(travese),
		 * Iterator(del) and ListIterator(CRUD) ? for
		 * System.out.println("----------------");
		 * 
		 * System.out.println("---sort as per id-");
		 * 
		 * Collections.sort(books); Iterator<Book> it = books.iterator();
		 * 
		 * while (it.hasNext()) { System.out.println(it.next()); }
		 * 
		 * System.out.println("---sort as per title-");
		 * 
		 * Collections.sort(books, new BookSorterAsPerTitle()); it =
		 * books.iterator();
		 * 
		 * while (it.hasNext()) { System.out.println(it.next()); }
		 * 
		 * System.out.println("---sort as per price-");
		 * 
		 * Collections.sort(books, new BookSorterAsPerPrice()); it =
		 * books.iterator();
		 * 
		 * while (it.hasNext()) { System.out.println(it.next()); }
		 */
	}

}
