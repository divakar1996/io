package com.day10.collections;
import java.util.*;

class MyKey implements Comparable<MyKey>{
	int i;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public MyKey(int i) {
		super();
		this.i = i;
	}

	public MyKey() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		return this.getI();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MyKey other = (MyKey) obj;
		if (i != other.i)
			return false;
		return true;
	}

	@Override
	public int compareTo(MyKey o) {
		return Integer.compare(this.getI(), o.getI());
	}
	
	
	
}
public class HashMapImpQ {

	public static void main(String[] args) {

		Map<MyKey, String>map=new HashMap<MyKey, String>();
		MyKey k=new MyKey(22);
		map.put(k, "key 22");
		
		map.put(new MyKey(822), "key 822");
		map.put(new MyKey(2), "key 2");
		map.put(new MyKey(229), "key 229");
		
		System.out.println(map.get(k));
	}

}













