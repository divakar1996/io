package com.day10.collections;
import java.util.*;
public class DemoWithoutGen {

	//U should never mix milk with wine!
	// u should never mix gen and non gen code!
	
	public static void main(String[] args) {
		List<String> l=new ArrayList<>();
		
		l.add("foo");
		l.add("bar");
		
		foof(l);
		
		for(String s: l)
			System.out.println(s);
		/*l.add(new MyKey());
		l.add(44);
		l.add("foo");
		l.add("yee");
		l.add(new Date());
		
		Iterator it=l.iterator();
		while(it.hasNext()){
			Object o=it.next();
		}*/
	}
	//xlint compiler option
	private static void foof(List l) {
		l.add(new Date());
	}
}








