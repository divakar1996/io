package com.day10.collections;
import java.util.*;

class StringSortingAsPerLength implements Comparator<String>{

	//GIGO
	@Override
	public int compare(String o1, String o2) {
		return Integer.compare(o2.length(), o1.length());
	}
	
}
public class DemoStringWithComparator {
	
	public static void main(String[] args) {
		
		List<String> list=Arrays.asList("foouuu","br","jarff","k","aaiiiiiii");
		
		Collections.sort(list,new StringSortingAsPerLength() );
		System.out.println(list);
		
	}

}
