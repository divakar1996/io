package com.day10.collections;
import java.util.*;

public class DemoHashTree {
	
	public static void main(String[] args) {
		Set<MyKey>s=new TreeSet<MyKey>(new Comparator<MyKey>() {

			@Override
			public int compare(MyKey o1, MyKey o2) {
				return Integer.compare(o2.getI(), o1.getI());
			}
		});
		
		s.add(new MyKey(112));
		s.add(new MyKey(1));
		s.add(new MyKey(882));
		s.add(new MyKey(16));
		
		for(MyKey k: s){
			System.out.println(k.getI());
		}
		
	}

}
