package com.day10.collections;
import java.util.*;
import java.util.Map.Entry;

public class DemoHashMap {
	
	public static void main(String[] args) {
		Map<String, Integer>map=new HashMap<String, Integer>();
		map.put("key1", 1);
		map.put("key2", 2);
		
		map.put("key3", 3);
		map.put("key4", 4);
		map.put("key1", 19);
		
		//how it iterate
		
		Set<String> keySet = map.keySet();
		
		for(String key: keySet){
			System.out.println(key+ "; "+ map.get(key));
		}
		
		//2 way!
		Set<Entry<String, Integer>> entrySet = map.entrySet();
		
		for(Entry<String, Integer> e: entrySet){
			System.out.println(e.getKey()+ " : "+ e.getValue());
		}
		
	}

}
